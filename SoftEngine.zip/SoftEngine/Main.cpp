#include "Engine.h"
#include "Menu.h"

int main(int argc, char** argv){

    Menu::GetInstance()->Init();

    while (Menu::GetInstance()->IsPlaying()){
        Menu::GetInstance()->GetMouse();
    }
    Menu::GetInstance()->Clean();


    return 0;
}
