#ifndef MENU_H
#define MENU_H

#include "SDL.h"
#include "SDL_image.h"
#include <time.h>

class Menu {
    public:
        static Menu* GetInstance(){
            return s_Instance = (s_Instance != nullptr)? s_Instance : new Menu();
        }
        bool Init();
        void Play();
        void Quit();
        void Renderer();
        void RendererM();
        void RenderV();
        void RenderL();
        void RenderH1();
        void RenderH2();
        void GetMouse();
        bool Clean();
        bool dead = false;
        bool wing = false;

        inline bool IsPlaying(){return is_Playing;}
        inline SDL_Renderer* GetRenderer(){return g_renderer;}
        clock_t start,endt;

    private:
        SDL_Window* g_window;
        SDL_Renderer* g_renderer;
        static Menu* s_Instance;
        bool is_Playing;
        int score;
        double time_play;
};

#endif // MENU_H
