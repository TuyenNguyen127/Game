#include "Menu.h"

#include "../Input/Input.h"
#include "TextureMenu.h"
#include "Text.h"
#include "Engine.h"
#include "SDL.h"

Menu* Menu::s_Instance = nullptr;
Engine* playstation = nullptr;
bool Menu::Init()
{
    if(SDL_Init(SDL_INIT_VIDEO)!=0 && IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG)!= 0){
        SDL_Log("Failed to initialize SDL: %s", SDL_GetError());
        return false;
    }

    g_window = SDL_CreateWindow("Menu", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREN_HEIGHT, 0);
    if(g_window == nullptr){
        SDL_Log("Failed to create Window: %s", SDL_GetError());
        return false;
    }

    g_renderer = SDL_CreateRenderer(g_window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if(g_renderer == nullptr){
        SDL_Log("Failed to create Renderer: %s", SDL_GetError());
        return false;
    }
    if (TTF_Init() < 0)
	{
		SDL_Log("%s", TTF_GetError());
		return -1;
	}
	TextureMenu::GetInstance()->Load("menu2","img/menu2.png");
	TextureMenu::GetInstance()->Load("gscreen", "img/menu1.png");
    TextureMenu::GetInstance()->Load("play", "img/play.png");
    TextureMenu::GetInstance()->Load("exit", "img/exit.png");
    TextureMenu::GetInstance()->Load("replay", "img/replay.png");
    TextureMenu::GetInstance()->Load("htp", "img/htp.png");
    TextureMenu::GetInstance()->Load("htp1","img/hpt1.png");
    TextureMenu::GetInstance()->Load("menu3", "img/menu3.png");
    TextureMenu::GetInstance()->Load("back", "img/back.png");
    TextureMenu::GetInstance()->Load("X", "img/X.png");
    TextureMenu::GetInstance()->Load("next", "img/next.png");
    TextureMenu::GetInstance()->Load("htp2", "img/htp1.png");
    Menu::GetInstance()->Renderer();
    return is_Playing = true ;
}
void Menu::Play(){
    Menu::GetInstance()->Clean();
    playstation->s_Instance = nullptr;

    playstation->GetInstance()->Init();
    start = clock();
    while(playstation->GetInstance()->IsRunning()){
        playstation->GetInstance()->Events();
        playstation->GetInstance()->Update();
        playstation->GetInstance()->Render();
    }
    endt = clock();
    playstation->GetInstance()->Clean();
    time_play = (double)(endt - start) / CLOCKS_PER_SEC;
    score = time_play;
    dead = true;
    Menu::GetInstance()->Init();
}
void Menu::Renderer(){
    SDL_RenderClear(g_renderer);
    if (Engine::GetInstance()->wingame==0) Menu::GetInstance()->RenderV();
        else if (Engine::GetInstance()->losegame==0) Menu::GetInstance()->RenderL();
        else Menu::GetInstance()->RendererM();
}
void Menu::RendererM(){
    if ( dead == false ){
        SDL_RenderClear(g_renderer);
        TextureMenu::GetInstance()->Draw("gscreen",0,0,1280,640);
        TextureMenu::GetInstance()->Draw("htp",0,0,40,40);
        TextureMenu::GetInstance()->Draw("exit", SCREEN_WIDTH/2+20, 500, 177, 50);
        TextureMenu::GetInstance()->Draw("play", SCREEN_WIDTH/2-197, 500, 177, 50);
        SDL_RenderPresent(g_renderer);
    }
    if ( dead == true ){
        SDL_RenderClear(g_renderer);
        TextureMenu::GetInstance()->Draw("menu2",0,0,1280,640);
        TextureMenu::GetInstance()->Draw("htp",0,0,40,40);
        TextureMenu::GetInstance()->Draw("exit", SCREEN_WIDTH/2+20, 300, 177, 50);
        TextureMenu::GetInstance()->Draw("replay", SCREEN_WIDTH/2-197, 300, 177, 50);
        std::string lt = "Your time:";
        Text::GetInstance()->LoadText(lt);
        Text::GetInstance()->LoadText("s");
        Text::GetInstance()->RenderText(lt, 500, 220);
        std::string scores = std::to_string(Menu::GetInstance()->score);
        Text::GetInstance()->LoadText(scores);
        Text::GetInstance()->RenderText(scores,710,220);
        Text::GetInstance()->RenderText("s", 710+Text::GetInstance()->Getw(scores),220);
        SDL_RenderPresent(g_renderer);
    }
}
void Menu::RenderH2(){
    SDL_RenderClear(g_renderer);
    TextureMenu::GetInstance()->Draw("htp1",0,0,1280,640);
    TextureMenu::GetInstance()->Draw("X",SCREEN_WIDTH-40,0,40,40);
    TextureMenu::GetInstance()->Draw("back",0,SCREN_HEIGHT/2-20,40,40);
    SDL_RenderPresent(g_renderer);
}
void Menu::RenderH1(){
    SDL_RenderClear(g_renderer);
    TextureMenu::GetInstance()->Draw("htp2",0,0,1280,640);
    TextureMenu::GetInstance()->Draw("X",SCREEN_WIDTH-40,0,40,40);
    TextureMenu::GetInstance()->Draw("next",SCREEN_WIDTH-40,SCREN_HEIGHT/2-20,40,40);
    SDL_RenderPresent(g_renderer);
}
void Menu::RenderL(){
    SDL_RenderClear(g_renderer);
    TextureMenu::GetInstance()->Draw("menu2",0,0,1280,640);
    TextureMenu::GetInstance()->Draw("htp",0,0,40,40);
    TextureMenu::GetInstance()->Draw("exit", SCREEN_WIDTH/2+20, 300, 177, 50);
    TextureMenu::GetInstance()->Draw("replay", SCREEN_WIDTH/2-197, 300, 177, 50);
    std::string lt = "You gave up on returning...";
    Text::GetInstance()->LoadText(lt);
    Text::GetInstance()->LoadText("s");
    Text::GetInstance()->RenderText(lt, 400, 220);
    SDL_RenderPresent(g_renderer);
}

void Menu::RenderV(){
    SDL_RenderClear(g_renderer);
    TextureMenu::GetInstance()->Draw("menu3", 0, 0, 1280, 640);
    TextureMenu::GetInstance()->Draw("htp",0,0,40,40);
    TextureMenu::GetInstance()->Draw("exit", SCREEN_WIDTH/2+20, 300, 177, 50);
    TextureMenu::GetInstance()->Draw("replay", SCREEN_WIDTH/2-197, 300, 177, 50);
    SDL_RenderPresent(g_renderer);
}

void Menu::GetMouse(){
    Input::GetInstance()->Listen();
}

bool Menu::Clean(){
    TextureMenu::GetInstance()->Clean();
    Text::GetInstance()->Clean();
    SDL_DestroyRenderer(g_renderer);
    SDL_DestroyWindow(g_window);
    IMG_Quit();
    SDL_Quit();
    //TTF_Quit();
}

void Menu::Quit()
{
    is_Playing = false;
}

