#include "Input.h"
#include "Engine.h"
#include "Menu.h"

Input* Input::s_Instance = nullptr;

Input::Input(){
    m_KeyStates = SDL_GetKeyboardState(nullptr);

}

void Input::Listen(){

    while (SDL_PollEvent(&event)){
        switch (event.type){
            case SDL_QUIT: {
                Engine::GetInstance()->Quit();
                Menu::GetInstance()->Quit();
                break;
            }
            case SDL_KEYDOWN: KeyDown();break;
            case SDL_MOUSEBUTTONDOWN: Mouse();break;
        }
    }
}

bool Input::GetKey(SDL_Scancode key){
    return (m_KeyStates[key] == 1);
}

void Input::KeyDown(){
    m_KeyStates = SDL_GetKeyboardState(nullptr);
}

void Input::Mouse(){

    if ( event.button.button == SDL_BUTTON_LEFT ){
        ct.x = event.button.x;
        ct.y = event.button.y;
        if (Engine::GetInstance()->IsRunning()){
            bool homex = (ct.x > SCREEN_WIDTH-180 && ct.x < SCREEN_WIDTH-140);
            bool homey = (ct.y > SCREN_HEIGHT-40 && ct.y < SCREN_HEIGHT);
            if ( homex && homey == true ) Engine::GetInstance()->Quit();

            bool quitx = (ct.x > SCREEN_WIDTH-60 && ct.x < SCREEN_WIDTH-20);
            bool quity = (ct.y > SCREN_HEIGHT-40 && ct.y < SCREN_HEIGHT);
            if ( quitx &&quity == true ) Engine::GetInstance()->Quit();
        }
        else {
            if (htp == true){
                bool exx = (ct.x > SCREEN_WIDTH-40 && ct.x < SCREEN_WIDTH);
                bool exy = (ct.y > 0 && ct.y < 40);
                if ( exx && exy == true ){
                    Menu::GetInstance()->Renderer();
                }
                bool nextx = (ct.x > SCREEN_WIDTH-40 && ct.x < SCREEN_WIDTH);
                bool nexty = (ct.y > SCREN_HEIGHT/2-20 && ct.y < SCREN_HEIGHT/2+20);
                if (nextx && nexty == true ) {
                    Menu::GetInstance()->RenderH2();
                }
                bool backx = (ct.x > 0 && ct.x < 40);
                bool backy = (ct.y > SCREN_HEIGHT/2-20 && ct.y < SCREN_HEIGHT/2+20);
                if (backx && backy == true) Menu::GetInstance()->RenderH1();
            }
            bool htpx = (ct.x > 0 && ct.x < 40);
            bool htpy = (ct.y > 0 && ct.y < 40);
            if ( htpx && htpy == true )
            {
                Menu::GetInstance()->RenderH1();
                htp = true;
            }
            else if ( Menu::GetInstance()->dead == true ){
                bool play_x = (ct.x > SCREEN_WIDTH/2-197 && ct.x < SCREEN_WIDTH/2-20);
                bool play_y = (ct.y > 300 && ct.y < 350);
                if ( play_x && play_y == true ) Menu::GetInstance()->Play();

                bool quit_x = (ct.x > SCREEN_WIDTH/2+20 && ct.x < SCREEN_WIDTH/2+197);
                bool quit_y = (ct.y > 300 && ct.y < 350);
                if ( quit_x && quit_y == true ) Menu::GetInstance()->Quit();
            }
            else {
                bool play_x = (ct.x > SCREEN_WIDTH/2-197 && ct.x < SCREEN_WIDTH/2-20);
                bool play_y = (ct.y > 500 && ct.y < 550);
                if ( play_x && play_y == true ) Menu::GetInstance()->Play();

                bool quit_x = (ct.x > SCREEN_WIDTH/2+20 && ct.x < SCREEN_WIDTH/2+197);
                bool quit_y = (ct.y > 500 && ct.y < 550);
                if ( quit_x && quit_y == true ) Menu::GetInstance()->Quit();
            }
        }
}}
