#ifndef INPUT_H
#define INPUT_H

#include "SDL.h"

class Input
{
    public:
        static Input* GetInstance(){ return s_Instance = (s_Instance != nullptr)? s_Instance : new Input(); }

        void Listen();
        bool GetKey(SDL_Scancode key);

    private:
        Input();
        void KeyDown();
        bool htp = false;
        void Mouse();
        const Uint8* m_KeyStates;
        static Input* s_Instance;
        SDL_Event event;
        SDL_Rect ct;
};

#endif // INPUT_H
