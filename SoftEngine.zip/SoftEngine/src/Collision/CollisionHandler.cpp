#include "CollisionHandler.h"

CollisionHandler* CollisionHandler::s_Instance = nullptr;

CollisionHandler::CollisionHandler(){

}

bool CollisionHandler::CheckCollision(Rect p, Rect m)
{
    bool x_overlaps = (p.x*1.11 < m.x + m.w) && ((p.x + p.w)*0.9 > m.x);
    bool y_overlaps = (p.y*1.11 < m.y + m.h) && ((p.y + p.h)*0.9 > m.y);
    return (x_overlaps && y_overlaps);
}


