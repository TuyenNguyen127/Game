#ifndef COLLISIONHANDLER_H
#define COLLISIONHANDLER_H

#include "SDL.h"

class Rect{
    public:
        float x,y,w,h;
    public:
        Rect( float x_=0, float y_=0, float w_=0, float h_=0 ): x(x_), y(y_), w(w_), h(h_){}
    public:
        inline Rect operator= (const Rect& r) const {
                return Rect( r.x, r.y, r.w, r.h );
        }
};


class CollisionHandler
{
    public:
        bool CheckCollision(Rect p, Rect m);
        inline static CollisionHandler* GetInstance(){ return s_Instance = (s_Instance == nullptr)? s_Instance : new CollisionHandler(); }

    private:
        CollisionHandler();
        bool stop_moving;
        static CollisionHandler* s_Instance;
};

#endif // COLLISIONHANDLER_H
