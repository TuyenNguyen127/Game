#ifndef AMONGUS_H
#define AMONGUS_H

#include "Character.h"
#include "RigidBody.h"
#include "CollisionHandler.h"

class AmongUs: public Character{

    public:
        AmongUs(Properties* props);

        virtual void Draw();
        virtual void Clean();
        virtual void Update(float dt);
        bool stop_moving;

    private:
        RigidBody* m_RigidBody;
        bool is_falling;
        bool is_die;
        float m_y;
};

#endif // AMONGUS_H
