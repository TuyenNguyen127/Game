#include "Prevent.h"
#include "TextureManager.h"
#include "../Input/Input.h"
#include "Engine.h"

Prevent::Prevent(Properties* props): Character(props)
{
    m_RigidBody = new RigidBody();
    stop_moving = false;
}

void Prevent::Draw()
{
    TextureManager::GetInstance()->Draw(m_TextureID, m_Transform->X, m_Transform->Y, m_Width, m_Height);
}

void Prevent::Update(float dt){
    m_RigidBody->SetLucX(-GRAVITY);

    if (stop_moving == true){
        m_RigidBody->Update(0);
    }
    else m_RigidBody->Update(0.5*dt);

    m_Transform->TranslateX(m_RigidBody->Position().X);

}
void Prevent::Clean()
{
    TextureManager::GetInstance()->Clean();
}

