#ifndef PREVENT_H
#define PREVENT_H

#include "SDL.h"
#include "Character.h"
#include "RigidBody.h"
#include "CollisionHandler.h"

class Prevent: public Character{

    public:
        Prevent();
        Prevent(Properties* props);

        virtual void Draw();
        virtual void Clean();
        virtual void Update(float dt);
        bool stop_moving;

    private:
        RigidBody* m_RigidBody;


};

#endif // PREVENT_H
