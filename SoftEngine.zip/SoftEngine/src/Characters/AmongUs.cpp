#include "AmongUs.h"
#include "TextureManager.h"
#include "SDL.h"
#include "../Input/Input.h"
#include "Engine.h"

AmongUs::AmongUs(Properties* props): Character(props) {
    m_RigidBody = new RigidBody();
    m_y = m_Transform->Y;
    stop_moving = false;
}

void AmongUs::Draw(){
    TextureManager::GetInstance()->Draw(m_TextureID, m_Transform->X, m_Transform->Y, m_Width, m_Height);
}

void AmongUs::Update(float dt){

    m_RigidBody->UnSetLuc();
    if (stop_moving == false)
        if ((Input::GetInstance()->GetKey(SDL_SCANCODE_SPACE))||(Input::GetInstance()->GetKey(SDL_SCANCODE_UP)))
            if (m_y > 0) m_RigidBody->SetLucY(-(GRAVITY*2));
            else m_RigidBody->SetLucY(0);


    m_y = m_Transform->Y;
    if (m_y >= SCREN_HEIGHT - m_Height/2 )  Engine::GetInstance()->Quit();
    m_RigidBody->Update(0.5*dt);
    m_Transform->TranslateY(m_RigidBody->Position().Y);

 }

void AmongUs::Clean(){
    TextureManager::GetInstance()->Clean();
}
