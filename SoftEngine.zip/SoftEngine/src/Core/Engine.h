#ifndef ENGINE_H
#define ENGINE_H

#include "SDL.h"
#include "SDL_image.h"
#include "GameObject.h"
#include<vector>

#define SCREEN_WIDTH 1280
#define SCREN_HEIGHT 640
#define NUM_PREVENT 99
#define RANGE 250

class Engine {

    public:
        static Engine* GetInstance(){
            return s_Instance = (s_Instance != nullptr)? s_Instance : new Engine();
        }

        bool Init();
        bool Clean();
        void Quit();

        void Update();
        void Render();
        void Events();

        inline bool IsRunning(){return m_IsRunning;}
        inline SDL_Renderer* GetRenderer(){return m_Renderer;}
        bool stop = false;
        bool gready = false;
        int wingame = 1,losegame = 1;

        static Engine* s_Instance;
    private:
        bool m_IsRunning;
        int sl = 199;
        SDL_Event e;
        SDL_Rect ct;
        SDL_Window* m_Window;
        SDL_Renderer* m_Renderer;


        std::vector<GameObject*> m_GameObjects;
};

#endif // ENGINE_H
