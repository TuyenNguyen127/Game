#include "Engine.h"
#include "TextureManager.h"
#include "../Input/Input.h"
#include "AmongUs.h"
#include "Prevent.h"
#include "SDL.h"
#include <iostream>
#include <ctime>
#include "Menu.h"

Engine* Engine::s_Instance = nullptr;
AmongUs* player = nullptr;
AmongUs* die = nullptr;
Prevent* endg = nullptr;
bool Engine::Init(){

    if(SDL_Init(SDL_INIT_VIDEO)!=0 && IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG)!= 0){
        SDL_Log("Failed to initialize SDL: %s", SDL_GetError());
        return false;
    }

    m_Window = SDL_CreateWindow("Engine", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREN_HEIGHT, 0);
    if(m_Window == nullptr){
        SDL_Log("Failed to create Window: %s", SDL_GetError());
        return false;
    }

    m_Renderer = SDL_CreateRenderer(m_Window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if(m_Renderer == nullptr){
        SDL_Log("Failed to create Renderer: %s", SDL_GetError());
        return false;
    }
    TextureManager::GetInstance()->Load("screen", "img/screen.jpg");
    TextureManager::GetInstance()->Load("player", "img/live.png");
    TextureManager::GetInstance()->Load("stone", "img/stone.png");
    TextureManager::GetInstance()->Load("hanhtinh_1" ,"img/hanhtinh_1.png");
    TextureManager::GetInstance()->Load("hanhtinh_2" ,"img/hanhtinh_2.png");
    TextureManager::GetInstance()->Load("ufo" ,"img/ufo.png");
    TextureManager::GetInstance()->Load("tau" ,"img/tau.png");
    TextureManager::GetInstance()->Load("vetinh" ,"img/vetinh.png");
    TextureManager::GetInstance()->Load("die", "img/die.png");
    TextureManager::GetInstance()->Load("quit", "img/quit.png");
    TextureManager::GetInstance()->Load("end", "img/end.png");

    Prevent* stone = nullptr;
    Prevent* ht1 = nullptr;
    Prevent* ht2 = nullptr;
    Prevent* tau = nullptr;
    Prevent* ufo = nullptr;
    Prevent* vetinh = nullptr;

    endg = new Prevent(new Properties("end",SCREEN_WIDTH,170,739,300));
    player = new AmongUs(new Properties("player", 320, 320, 44, 57));
    die = new AmongUs(new Properties("die", 320 , 320 , 63, 77));
    srand((int)time(0));

    for (int i=0; i<=sl; i++){
        int vt=rand()%6;
        if (vt==1) {
            stone = new Prevent(new Properties("stone", (SCREEN_WIDTH) + i*RANGE , rand()%457,191,183));
            m_GameObjects.push_back(stone);
        }
        if (vt==2) {
            ht1 = new Prevent(new Properties("hanhtinh_1", (SCREEN_WIDTH) + i*RANGE, rand()%530,200,110));
            m_GameObjects.push_back(ht1);
        }
        if (vt==3) {
            ht2 = new Prevent(new Properties("hanhtinh_2", (SCREEN_WIDTH) + i*RANGE, rand()%465,200,135));
            m_GameObjects.push_back(ht2);
        }
        if (vt==4) {
            tau = new Prevent(new Properties("tau", (SCREEN_WIDTH) + i*RANGE, rand()%448,200,152));
            m_GameObjects.push_back(tau);
        }
        if (vt==5) {
            ufo = new Prevent(new Properties("ufo", (SCREEN_WIDTH) + i*RANGE, rand()%465,200,109));
            m_GameObjects.push_back(ufo);
        }
        if (vt==0) {
            vetinh = new Prevent(new Properties("vetinh", (SCREEN_WIDTH) + i*RANGE, rand()%523 ,114,77));
            m_GameObjects.push_back(vetinh);
        }
    }

    return m_IsRunning = true;
}

void Engine::Render(){

    SDL_RenderClear(m_Renderer);
    TextureManager::GetInstance()->Draw("screen",0,0,1280,640);
    if (gready == true) endg->Draw();
    if ( stop == false ) player->Draw();
    else die->Draw();
    for( unsigned int i = 0; i !=m_GameObjects.size(); i++)
        m_GameObjects[i]->Draw();
    TextureManager::GetInstance()->Draw("quit", SCREEN_WIDTH-60, SCREN_HEIGHT-40, 40, 40);
    SDL_RenderPresent(m_Renderer);
}

void Engine::Update(){
    Rect p,m,p1;
    if ( stop == false ) {
        player->Update(1);
        die->Update(1);
        for( unsigned int i = 0; i !=m_GameObjects.size(); i++)
        {
            m_GameObjects[i]->Update(1);
            p.x = m_GameObjects[i]->m_Transform->X;
            p.y = m_GameObjects[i]->m_Transform->Y;
            p.w = m_GameObjects[i]->m_Width;
            p.h = m_GameObjects[i]->m_Height;
            m.x = player->m_Transform->X;
            m.y = player->m_Transform->Y;
            m.w = player->m_Width;
            m.h = player->m_Height;
            bool kt = CollisionHandler::GetInstance()->CheckCollision(p,m);
            if ( kt == true ) stop = true;
        }
            if ( m_GameObjects[sl]->m_Transform->X + m_GameObjects[sl]->m_Width < player->m_Transform->X){
                gready = true;
                endg->Update(1);
                p1.x = endg->m_Transform->X;
                p1.y = endg->m_Transform->Y;
                p1.w = endg->m_Width;
                p1.h = endg->m_Height;
                m.x = player->m_Transform->X;
                m.y = player->m_Transform->Y;
                m.w = player->m_Width;
                m.h = player->m_Height;
                bool kt1 = CollisionHandler::GetInstance()->CheckCollision(p1,m);
                if ( kt1 == true )
                {
                    wingame = 0;
                    Engine::GetInstance()->Quit();
                }
                if ( p1.x + p1.w < m.x )
                {
                    losegame = 0;
                    Engine::GetInstance()->Quit();
                }
            }

    }
    else {
        die->stop_moving = true;
        die->Update(1);

    }
}

void Engine::Events(){
    Input::GetInstance()->Listen();
}

bool Engine::Clean(){
    for( unsigned int i = 0; i !=m_GameObjects.size(); i++)
        m_GameObjects[i]->Clean();
    TextureManager::GetInstance()->Clean();
    SDL_DestroyRenderer(m_Renderer);
    SDL_DestroyWindow(m_Window);
    IMG_Quit();
    SDL_Quit();
}


void Engine::Quit(){
    m_IsRunning = false;

}
