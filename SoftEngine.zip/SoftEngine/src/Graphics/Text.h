#ifndef TEXT_H
#define TEXT_H

#include "SDL_ttf.h"
#include <string>
#include <map>
#include "SDL.h"

class Text
{
    public:
        static Text* GetInstance(){ return s_Instance = (s_Instance != nullptr)? s_Instance : new Text();}

        bool LoadText(std::string id);
        void RenderText(std::string id, int x, int y);
        void Clean();
        SDL_Rect srcRect ;
        SDL_Rect dstRect ;
        int Getw(std::string id) {return srcRect.w;}
    private:
        std::map<std::string, SDL_Texture*> m_TextureMap;
        static Text* s_Instance;
        SDL_Color color = {255, 255, 255};
        SDL_Texture* texture;
        TTF_Font* font = TTF_OpenFont("font/ARCADE.ttf", 38);


};

#endif // TEXT_H
