#include "Text.h"
#include "Menu.h"

Text* Text::s_Instance = nullptr;

bool Text::LoadText( std::string id)
{
    SDL_Surface* surface = TTF_RenderText_Solid(font, id.c_str(), color);
    if(surface == nullptr){
        SDL_Log("Failed to load texture: %s, %s", id.c_str(), SDL_GetError());
        return false;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(Menu::GetInstance()->GetRenderer(), surface);
    if(texture == nullptr){
        SDL_Log("Failed to create texture from surface: %s", SDL_GetError());
        return false;
    }

    SDL_FreeSurface( surface );

    m_TextureMap[id] = texture;
    return true;
}

void Text::RenderText(std::string id, int x, int y){


    TTF_SizeText(font, id.c_str(), &srcRect.w, &srcRect.h);
    srcRect.x = 0;
	srcRect.y = 0;

	dstRect.x = x;
	dstRect.y = y;

	dstRect.w = srcRect.w;
	dstRect.h = srcRect.h;

    SDL_RenderCopy(Menu::GetInstance()->GetRenderer(), m_TextureMap[id], &srcRect, &dstRect);

}

void Text::Clean(){
    std::map<std::string, SDL_Texture*>::iterator it;
    for(it = m_TextureMap.begin(); it != m_TextureMap.end(); it++)
        SDL_DestroyTexture(it->second);

    m_TextureMap.clear();

}
