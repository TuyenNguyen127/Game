#ifndef TEXTUREMENU_H
#define TEXTUREMENU_H

#include <string>
#include "SDL.h"
#include <map>

class TextureMenu
{
    public:
        static TextureMenu* GetInstance(){ return s_Instance = (s_Instance != nullptr)? s_Instance : new TextureMenu();}

        bool Load(std::string id, std::string filename);
        void Clean();

        void Draw(std::string id, int x, int y, int width, int heigt);

    private:
        TextureMenu(){}
        std::map<std::string, SDL_Texture*> m_TextureMap;
        static TextureMenu* s_Instance;
};
#endif // TEXTUREMENU_H
