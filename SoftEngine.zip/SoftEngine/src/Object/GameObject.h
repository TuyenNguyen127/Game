#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include "IObject.h"
#include "Transform.h"
#include "SDL.h"

struct Properties{

    public:
        Properties(std::string textureID, float x, float y, float width, float height){
            X = x;
            Y = y;
            Width = width;
            Height = height;
            TextureID = textureID;
        }

    public:
        std::string TextureID;
        float Width, Height;
        float X, Y;
};

class GameObject : public IObject {
    public:
        GameObject(Properties* props): m_TextureID(props->TextureID),
            m_Width(props->Width), m_Height(props->Height){

            m_Transform = new Transform(props->X, props->Y);
        }

        virtual void Draw()=0;
        virtual void Clean()=0;
        virtual void Update(float dt)=0;
        bool stop=false;

    public:
        Transform* m_Transform;
        float m_Width, m_Height;
        std::string m_TextureID;
};

#endif // GAMEOBJECT_H
